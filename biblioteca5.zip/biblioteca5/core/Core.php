<?php


class Core {
    public function run() {
        $params = array();
        $url = '/';
        if(isset($_GET['url'])) {
			$url .= $_GET['url'];
		}
                
                if(!empty($url) && $url != '/') {
                    $url = explode('/', $url);
                    array_shift($url);
                    
                    $currentController = $url[0].'Controller';
                    array_shift($url);
                    
                    if(isset($url[0]) && !empty($url[0])) {
				$currentAction = $url[0];
                    }else {
				$currentAction = 'index';
			}
                }else{
                    $currentController = 'homeController';
			$currentAction = 'index';
                }
                if(!file_exists('controllers/'.$currentController.'.php')) {
			$currentController = 'naoencontradoController';
			$currentAction = 'index';
		}
                    $c = new $currentController();

		call_user_func_array(array($c, $currentAction), $params);
}
}
