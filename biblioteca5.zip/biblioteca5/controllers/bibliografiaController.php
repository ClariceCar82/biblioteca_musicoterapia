<?php


class bibliografiaController extends controller{
	
public function index() {
		$dados = array();

		$bibliografia = new bibliografia();
		$dados['lista'] = $bibliografia->getLista();

		  $this->loadTemplate('bibliografia', $dados);
	}

        
      }

