<?php


class revistasController extends controller{
	
	
	public function index() {
		$dados = array();

		$revistas = new revistas();
		$dados['rev'] = $revistas->getLista();

          $this->loadTemplate('revistas', $dados);
      }
}
