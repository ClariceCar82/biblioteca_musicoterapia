<?php

class naoencontradoController extends controller {
    
   public function index() {
     $dados = array();
  
;

     $this->loadTemplate('naoencontrado', $dados);
   } 

}