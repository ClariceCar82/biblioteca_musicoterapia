<?php


class artigoslivrosController extends controller{
	
	
	public function index() {
		$dados = array();

		$artigoslivros = new artigoslivros();
		$dados['cap'] = $artigoslivros->getLista();

          $this->loadTemplate('artigoslivros', $dados);
      }
}
