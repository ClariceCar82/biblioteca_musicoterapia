<?php


class VoicesController extends controller{
	
	
	public function index() {
		$dados = array();

		$voices= new voices();
		$dados['voi'] = $voices->getLista();

          $this->loadTemplate('voices', $dados);
      }
}
