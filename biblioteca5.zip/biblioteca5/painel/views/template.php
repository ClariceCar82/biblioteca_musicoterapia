<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <title>Biblioteca da Musicoterapia</title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" type="text/css" href="<?php echo BASE_URL; ?>assets/css/style.css">
    </head>
    <body>
        <header>
        <div class="container topo">    
            <div class="menu">
                <nav>
                    <ul>
                        <li><a href="<?php echo BASE_URL; ?>">Home</a></li>
                        <li><a href="<?php echo BASE_URL; ?>bibliografia">Bibliografia</a></li>
                        <li><a href="<?php echo BASE_URL; ?>acervo">Acervo</a></li>
                        <li><a href="<?php echo BASE_URL; ?>sobre">Sobre</a></li>
                    </ul>
                </nav> 
            </div>
            <div class="logo">
                <nav>
                    <ul>
                        <li><a href="<?php echo BASE_URL; ?>login">Login</a></li>
                    </ul>
                </nav>
            </div>
            
            </div>
         
            
        </header>
        <section id="banner">
            <div class="container column">
                <div class="banner_headline">
                    <h1>Biblioteca da Musicoterapia</h1>
                </div>
            </div>
        </section>
        <div class="space"></div>
        <section id="conteudo">
            <div class="container">
            <?php $this->loadViewInTemplate($viewName, $viewData); ?>   
            </div>
        </section>
        <div></div>  
        <footer>
            Desenvolvimento Web Clarice Cardeman
        </footer>
    </body>
</html>
