
<div class="container_menu">
            <div class="menu_centro">
                <nav>
                    <ul>
                        <li><a href="<?php echo BASE_URL; ?>bibliografia">Livros</a></li>
                        <li><a href="<?php echo BASE_URL; ?>artigoslivros">Capítulos em Livros</a></li>
                        <li><a href="<?php echo BASE_URL; ?>revistas">Artigos em Revistas</a></li>
                        <li><a href="<?php echo BASE_URL; ?>voices">No Voices</a></li>
                    </ul>
                </nav> 
            </div>
    <br>
    <center> <h3>Bibliografia - Livros</h3></center>
   <div style="overflow-x:auto;">
    <table>
        <tr>
    <th>Autor</th>
    <th>Título</th>
    <th>Editora</th>
    <th>Ano</th>
     <?php foreach($lista as $item): ?>   
    <tr><td><?=utf8_encode($item['autor'])?></td>
        <td><?=utf8_encode($item['titulo_livro'])?></td>
        <td><?=utf8_encode($item['editora'])?></td>
    <td><?php echo $item['ano']; ?></td></tr>
    <?php endforeach; ?>
   
       
    </table>

</div>
</div>
<div style="clear: both"></div>





