<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


class Artigoslivros extends model {

	public function getLista() {
		$array = array();
		$sql = $this->db->query("SELECT * FROM capitulo_livro");
		if($sql->rowCount() > 0) {
			$array = $sql->fetchAll();
		}

		return $array;
	}

}
?>