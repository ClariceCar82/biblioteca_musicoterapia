
<div class="container_menu">
            <div class="menu_centro">
                <nav>
                    <ul>
                        <li><a href="<?php echo BASE_URL; ?>bibliografia">Livros</a></li>
                        <li><a href="<?php echo BASE_URL; ?>artigoslivros">Capítulos em Livros</a></li>
                        <li><a href="<?php echo BASE_URL; ?>revistas">Artigos em Revistas</a></li>
                        <li><a href="<?php echo BASE_URL; ?>voices">No Voices</a></li>
                    </ul>
                </nav> 
            </div>
    <br>
    <center> <h3>Bibliografia - Capítulos em Livros</h3></center>
   <div style="overflow-x:auto;">
    <table>
        <tr>
    <th>Autor</th>
    <th>Título</th>
    <th>Livro</th>
    <th>Autor/Organizador</th>
    <th>Ano</th>
     <?php foreach($cap as $item): ?>      
    <tr><td><?=utf8_encode($item['autor'])?></td>
        <td><?=utf8_encode($item['titulo_capitulo'])?></td>
        <td><?=utf8_encode($item['titulo_livro'])?></td>
        <td><?=utf8_encode($item['autor_livro'])?></td>
        
    <td><?=utf8_encode($item['ano'])?></td></tr>
   <?php endforeach; ?>
        </tr>
    </table>
     
</div>
</div>

